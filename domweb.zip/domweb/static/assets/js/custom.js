
//
// document.getElementById("call-back-button").onclick = function (){
//     name = document.getElementById("formGroupExampleInput").value
//     mob = document.getElementById("formGroupExampleInput2").value
//     email = document.getElementById("formGroupExampleInput3").value
//
//     console.log(name)
//     console.log(mob)
//     console.log(email)
// }
//
