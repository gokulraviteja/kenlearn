from django.shortcuts import render , HttpResponse

# Create your views here.
from .dao import filebasedio

def home(request):
    return  render(request , "app/index.html")

def callback_requested(request):
    name = request.POST["name"]
    mob = request.POST["mobile"]
    email = request.POST["email"]
    filebasedio.insert_contact_details(name , mob , email)
    return render(request, "app/callback_requested.html")

def registered_contacts(request):
    if("key" not in request.GET or request.GET["key"]!="dom"):

        return render(request, "app/restricted.html")
    else:
        contacts = filebasedio.get_contacts()
        return render(request, "app/registered_contacts.html", {"contacts": contacts})
