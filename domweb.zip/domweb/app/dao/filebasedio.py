


def insert_contact_details(name ,mobile ,email ):
    f=open("contacts.txt" , 'a')
    f.write(name+" $ "+mobile+" $ "+email+"\n")
    f.close()

def get_contacts():
    f = open("contacts.txt")
    s=""
    for i in f:
        s+=i
    f.close()
    s=s.split("\n")
    a=[]
    for i in s:
        j = i.split(" $ ")
        if(len(j)==3):
            d={"name":j[0] , "mob": j[1] , "email": j[2]}
            a.append(d)
    return a



